import threading
import time
import random

# Constants
NUM_PHILOSOPHERS = 5
MAX_EATING_TIME = 3  # Time in seconds

# Semaphores
semaphores = [threading.Semaphore(1) for _ in range(NUM_PHILOSOPHERS)]
states = ['thinking' for _ in range(NUM_PHILOSOPHERS)]  # Initial states of philosophers

# Mutex for printing
print_lock = threading.Lock()

# Function to simulate philosopher's actions
def philosopher(id):
    while True:
        # Philosopher is thinking
        time.sleep(random.uniform(1, 3))  # Thinking time
        print(f"Philosopher {id} is thinking.")

        # Philosopher is hungry and wants to eat
        states[id] = 'hungry'
        print(f"Philosopher {id} is hungry.")

        # Try to eat
        try_to_eat(id)

        # Eating
        eating_time = random.uniform(1, MAX_EATING_TIME)
        print(f"Philosopher {id} is eating for {eating_time:.2f} seconds.")
        time.sleep(eating_time)

        # Finish eating and return to thinking
        states[id] = 'thinking'
        print(f"Philosopher {id} is done eating.")

def try_to_eat(id):
    left = (id - 1) % NUM_PHILOSOPHERS
    right = (id + 1) % NUM_PHILOSOPHERS

    # Check if both left and right philosophers are eating
    while states[left] == 'eating' or states[right] == 'eating':
        time.sleep(0.1)  # Wait if left or right are eating

    # Both left and right philosophers are not eating, philosopher can eat
    if states[id] == 'hungry':
        print(f"Philosopher {id} can now eat.")
        states[id] = 'eating'

        # Acquire semaphores for left and right forks (resources)
        semaphores[left].acquire()
        semaphores[right].acquire()

        print(f"Philosopher {id} is eating...")

        # Release semaphores after eating
        semaphores[left].release()
        semaphores[right].release()

# Create threads for each philosopher
threads = []
for i in range(NUM_PHILOSOPHERS):
    thread = threading.Thread(target=philosopher, args=(i,))
    threads.append(thread)
    thread.start()

# Wait for all threads to finish (this is optional as the philosophers will run indefinitely)
for thread in threads:
    thread.join()

