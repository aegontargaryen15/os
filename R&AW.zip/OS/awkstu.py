# Function to calculate result based on total marks and percentage
def calculate_result(total_marks, percentage):
    if percentage < 40:
        return "Fail"
    elif 60 <= percentage <= 65:
        return "First Class"
    elif percentage > 66:
        return "Distinction"
    else:
        return "Pass"

# Function to process student records from a file
def process_student_records(file_name):
    try:
        # Open the student record file
        with open(file_name, 'r') as file:
            records = file.readlines()

        # Process each student record
        for record in records:
            # Strip any leading/trailing whitespace and skip blank lines
            record = record.strip()
            if not record:
                continue

            # Split the record by spaces/tabs to extract student data
            data = record.split()
            if len(data) < 4:  # Ensure there are at least 4 fields (name + 3 marks)
                print(f"Skipping invalid record: {record}")
                continue

            name = data[0]
            try:
                marks = list(map(int, data[1:]))  # Convert subject marks to integers
            except ValueError:
                print(f"Skipping record with invalid marks: {record}")
                continue

            total_marks = sum(marks)  # Calculate total marks
            percentage = (total_marks / len(marks))  # Calculate percentage

            # Determine the result
            result = calculate_result(total_marks, percentage)

            # Print the student's result
            print(f"Student: {name}")
            print(f"Total Marks: {total_marks}")
            print(f"Percentage: {percentage:.2f}%")
            print(f"Result: {result}\n")

    except FileNotFoundError:
        print(f"Error: The file '{file_name}' was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

# User input for the file containing student records
file_name = input("Enter the name of the student record file (e.g., 'student_records.txt'): ")
process_student_records(file_name)

