                                      #USING MUTEX AND THREAD

import threading
import time

# Shared variables
data = 0
read_count = 0
mutex = threading.Lock()
write_lock = threading.Lock()

def reader(reader_id):
    global read_count
    while True:
        with mutex:
            read_count += 1
            if read_count == 1:
                write_lock.acquire()
        # Reading data
        print(f"Reader {reader_id} is reading data: {data}")
        time.sleep(1)  # Simulate reading
        with mutex:
            read_count -= 1
            if read_count == 0:
                write_lock.release()
        time.sleep(1)

def writer(writer_id):
    global data
    while True:
        write_lock.acquire()
        # Writing data
        data += 1
        print(f"Writer {writer_id} updated data to: {data}")
        time.sleep(1)  # Simulate writing
        write_lock.release()
        time.sleep(1)

# User input
num_readers = int(input("Enter number of readers: "))
num_writers = int(input("Enter number of writers: "))

threads = []
for i in range(num_readers):
    t = threading.Thread(target=reader, args=(i+1,))
    threads.append(t)
    t.start()

for i in range(num_writers):
    t = threading.Thread(target=writer, args=(i+1,))
    threads.append(t)
    t.start()

for t in threads:
    t.join()

