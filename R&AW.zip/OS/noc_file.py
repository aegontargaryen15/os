# Read the file and split into words
file_path = input("Enter the path to the text file: ")

try:
    with open(file_path, 'r') as file:
        # Read the file content
        text = file.read()

    # Split the content into words (similar to flatMap in Spark)
    words = text.split()

    # Count occurrences of each word using a dictionary (similar to map and reduceByKey in Spark)
    word_count = {}
    for word in words:
        word_count[word] = word_count.get(word, 0) + 1

    # Display the result (similar to collect in Spark)
    for word, count in word_count.items():
        print(f"{word}: {count}")

except FileNotFoundError:
    print("The file was not found. Please check the path and try again.")
