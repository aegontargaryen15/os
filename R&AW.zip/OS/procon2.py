import threading
import time
import random

# Buffer and Lock
buffer = []
buffer_size = int(input("Enter buffer size: "))
mutex = threading.Lock()

# Condition Variables
not_full = threading.Condition(mutex)
not_empty = threading.Condition(mutex)

# Producer Function
def producer():
    while True:
        item = random.randint(1, 100)
        with not_full:
            while len(buffer) == buffer_size:
                not_full.wait()
            buffer.append(item)
            print(f"Produced: {item}, Buffer: {buffer}")
            not_empty.notify()
        time.sleep(random.random())

# Consumer Function
def consumer():
    while True:
        with not_empty:
            while not buffer:
                not_empty.wait()
            item = buffer.pop(0)
            print(f"Consumed: {item}, Buffer: {buffer}")
            not_full.notify()
        time.sleep(random.random())

# Creating Threads
producer_thread = threading.Thread(target=producer)
consumer_thread = threading.Thread(target=consumer)

producer_thread.start()
consumer_thread.start()

