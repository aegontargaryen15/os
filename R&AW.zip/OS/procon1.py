                                    #USING THREADS AND SEMAPHOREimport threading
import time
import random

# Buffer and Semaphore
buffer = []
buffer_size = int(input("Enter buffer size: "))
full = threading.Semaphore(0)
empty = threading.Semaphore(buffer_size)
lock = threading.Lock()

# Producer Function
def producer():
    while True:
        item = random.randint(1, 100)
        empty.acquire()
        lock.acquire()
        buffer.append(item)
        print(f"Produced: {item}, Buffer: {buffer}")
        lock.release()
        full.release()
        time.sleep(random.random())

# Consumer Function
def consumer():
    while True:
        full.acquire()
        lock.acquire()
        item = buffer.pop(0)
        print(f"Consumed: {item}, Buffer: {buffer}")
        lock.release()
        empty.release()
        time.sleep(random.random())

# Creating Threads
producer_thread = threading.Thread(target=producer)
consumer_thread = threading.Thread(target=consumer)

producer_thread.start()
consumer_thread.start()

