# FCFS Scheduling Algorithm

def fcfs_scheduling(processes, burst_times):
    n = len(processes)
    wait_times = [0] * n
    turnaround_times = [0] * n

    # Calculating waiting time
    for i in range(1, n):
        wait_times[i] = wait_times[i - 1] + burst_times[i - 1]

    # Calculating turnaround time
    for i in range(n):
        turnaround_times[i] = wait_times[i] + burst_times[i]

    # Display results
    print("\nProcess\tBurst Time\tWaiting Time\tTurnaround Time")
    for i in range(n):
        print(f"{processes[i]}\t{burst_times[i]}\t\t{wait_times[i]}\t\t{turnaround_times[i]}")
    
    print(f"\nAverage Waiting Time: {sum(wait_times)/n:.2f}")
    print(f"Average Turnaround Time: {sum(turnaround_times)/n:.2f}")


# User Input
n = int(input("Enter the number of processes: "))
processes = [f"P{i+1}" for i in range(n)]
burst_times = [int(input(f"Enter burst time for {processes[i]}: ")) for i in range(n)]

fcfs_scheduling(processes, burst_times)

