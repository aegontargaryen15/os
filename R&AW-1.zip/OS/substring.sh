#!/bin/bash

# Get user input
read -p "Enter a string: " user_string
read -p "Enter the substring to check: " sub_string

# Check if the substring exists
if [[ $user_string == *$sub_string* ]]; then
    echo "Substring found!"
else
    echo "Substring not found!"
fi

