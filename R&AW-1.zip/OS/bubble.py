# Bubble Sort in Python with user input

# Step 1: Accept how many numbers to be sorted
n = int(input("Enter the number of elements to sort: "))

# Step 2: Accept the numbers in an array
num = []
print(f"Enter {n} numbers:")
for i in range(n):
    num.append(int(input(f"Enter element {i+1}: ")))

# Step 3: Initialize i to 0 (no need for j to be initialized as 0 outside the loop)
# Step 4: Bubble Sort Process
for i in range(n):
    for j in range(0, n-i-1):  # Decrease the range with each pass
        if num[j] > num[j+1]:
            # Step 5: Swap elements if they are in the wrong order
            num[j], num[j+1] = num[j+1], num[j]

# Step 6: Display the sorted list
print("Sorted list:", num)

