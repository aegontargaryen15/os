import threading
import time


# Shared variables
data = 0
read_count = 0
mutex = threading.Lock()
write_lock = threading.Lock()

# Stop flag to indicate when to stop the threads
stop_flag = False


def reader(reader_id):
    global read_count
    while not stop_flag:
        with mutex:
            read_count += 1
            if read_count == 1:
                write_lock.acquire()
        # Reading data
        print(f"Reader {reader_id} is reading data: {data}")
        time.sleep(1)  # Simulate reading
        with mutex:
            read_count -= 1
            if read_count == 0:
                write_lock.release()
        time.sleep(1)


def writer(writer_id):
    global data
    while not stop_flag:
        write_lock.acquire()
        # Writing data
        data += 1
        print(f"Writer {writer_id} updated data to: {data}")
        time.sleep(1)  # Simulate writing
        write_lock.release()
        time.sleep(1)


# Function to stop threads after a certain time (e.g., 10 seconds)
def stop_threads():
    global stop_flag
    time.sleep(10)  # Run for 10 seconds before stopping
    stop_flag = True  # Signal to stop the threads


# User input
num_readers = int(input("Enter number of readers: "))
num_writers = int(input("Enter number of writers: "))


threads = []

# Start reader threads
for i in range(num_readers):
    t = threading.Thread(target=reader, args=(i + 1,))
    threads.append(t)
    t.start()

# Start writer threads
for i in range(num_writers):
    t = threading.Thread(target=writer, args=(i + 1,))
    threads.append(t)
    t.start()

# Start the stop thread to terminate threads after some time
stop_thread = threading.Thread(target=stop_threads)
stop_thread.start()

# Wait for all threads to finish
for t in threads:
    t.join()

# Wait for the stop thread to finish
stop_thread.join()

print("Program terminated gracefully.")

