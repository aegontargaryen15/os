# Get user input
text = input("Enter a string of text: ")

# Get the word to count occurrences of
word = input("Enter the word to count occurrences: ")

# Count the occurrences of the word in the text
count = text.split().count(word)

# Display the result
print(f"The word '{word}' appears {count} time(s) in the text.")
