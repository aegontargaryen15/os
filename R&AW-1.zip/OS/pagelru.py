def lru(page_sequence, frame_count):
    frames = []
    page_faults = 0

    for page in page_sequence:
        if page not in frames:
            if len(frames) < frame_count:
                frames.append(page)
            else:
                least_used = frames.pop(0)
                frames.append(page)
            page_faults += 1
        else:
            frames.remove(page)
            frames.append(page)
        print(f"Frames: {frames}")
    print(f"Total Page Faults: {page_faults}")

pages = list(map(int, input("Enter page sequence (space-separated): ").split()))
frame_count = int(input("Enter number of frames: "))
lru(pages, frame_count)

