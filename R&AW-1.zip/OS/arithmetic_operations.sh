#!/bin/bash

# Function to perform arithmetic operations
perform_operation() {
    case $choice in
    1)
        result=$((num1 + num2))
        echo "Sum: $result"
        ;;
    2)
        result=$((num1 - num2))
        echo "Difference: $result"
        ;;
    3)
        result=$((num1 * num2))
        echo "Product: $result"
        ;;
   
    4)
        echo "Decimal Division (using bc):"
        echo "scale=2; $num1 / $num2" | bc
        ;;
    *)
        echo "Invalid choice! Please select a valid option."
        ;;
    esac
}

while true; do

  echo
    echo "Select an arithmetic operation:"
    echo "1. Addition"
    echo "2. Subtraction"
    echo "3. Multiplication"
    echo "4. Division (decimal)"
    echo "5. Exit"
    echo "Enter your choice: "
    read choice
    
    if [ $choice -eq 5 ]; then
        echo "Exiting the program. Goodbye!"
        break
    fi
    
    echo "Enter the first number: "
    read num1
    echo "Enter the second number: "
    read num2


    perform_operation
    echo
done

