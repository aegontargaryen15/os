#!/bin/bash

read -p "Enter a string: " str
# Convert the input string to lowercase
lower_str=$(echo "$str" | tr '[:upper:]' '[:lower:]')
# Reverse the string
reverse=$(echo "$lower_str" | rev)

if [ "$lower_str" == "$reverse" ]; then
    echo "The string '$str' is a palindrome."
else
    echo "The string '$str' is not a palindrome."
fi

