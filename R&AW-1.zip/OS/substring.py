def substring_check():
    # Step 1: Start
    print("Substring Checker")

    # Step 2: Accept the two strings
    string1 = input("Enter the main string: ")
    string2 = input("Enter the substring to search for: ")

    # Step 3 to 6: Compare character by character
    positions = []
    len1, len2 = len(string1), len(string2)

    for i in range(len1 - len2 + 1):
        match_found = True
        for j in range(len2):
            if string1[i + j] != string2[j]:
                match_found = False
                break
        if match_found:
            positions.append(i)

    # Step 7: Display the result
    if positions:
        print(f"Substring exists at positions: {positions}")
    else:
        print("Substring does not exist")

    # Step 8: Stop

# Call the function
substring_check()

