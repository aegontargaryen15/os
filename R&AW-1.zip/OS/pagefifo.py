def fifo(page_sequence, frame_count):
    frames = []
    page_faults = 0

    for page in page_sequence:
        if page not in frames:
            if len(frames) < frame_count:
                frames.append(page)
            else:
                frames.pop(0)
                frames.append(page)
            page_faults += 1
        print(f"Frames: {frames}")
    print(f"Total Page Faults: {page_faults}")

pages = list(map(int, input("Enter page sequence (space-separated): ").split()))
frame_count = int(input("Enter number of frames: "))
fifo(pages, frame_count)

