# Banker's Algorithm in Python

def calculate_need(maximum, allocation):
    """
    Calculate the need matrix based on maximum and allocation matrices.
    """
    return [[maximum[i][j] - allocation[i][j] for j in range(len(maximum[0]))] for i in range(len(maximum))]

def is_safe_state(processes, available, maximum, allocation):
    """
    Check if the system is in a safe state and find the safe sequence.
    """
    need = calculate_need(maximum, allocation)
    n, m = len(processes), len(available)  # Number of processes and resources

    finish = [False] * n  # Tracks if a process is completed
    safe_sequence = []  # Stores the safe sequence
    work = available[:]  # Copy of available resources

    while len(safe_sequence) < n:
        found = False
        for i in range(n):
            if not finish[i]:
                # Check if resources can satisfy the need of process i
                if all(need[i][j] <= work[j] for j in range(m)):
                    # If satisfied, allocate resources and mark process as finished
                    for j in range(m):
                        work[j] += allocation[i][j]
                    safe_sequence.append(processes[i])
                    finish[i] = True
                    found = True
                    break
        if not found:
            # No process could be allocated, unsafe state
            return False, []

    return True, safe_sequence

# Input: Number of processes and resources
n = int(input("Enter number of processes: "))
m = int(input("Enter number of resource types: "))

processes = [f"P{i}" for i in range(n)]

# Input: Allocation matrix
print("\nEnter allocation matrix:")
allocation = [list(map(int, input(f"Process {i}: ").split())) for i in range(n)]

# Input: Maximum matrix
print("\nEnter maximum matrix:")
maximum = [list(map(int, input(f"Process {i}: ").split())) for i in range(n)]

# Input: Available resources
print("\nEnter available resources:")
available = list(map(int, input().split()))

# Perform safety check
is_safe, safe_sequence = is_safe_state(processes, available, maximum, allocation)

if is_safe:
    print("\nSystem is in a safe state.")
    print("Safe Sequence:", " -> ".join(safe_sequence))
else:
    print("\nSystem is not in a safe state.")

