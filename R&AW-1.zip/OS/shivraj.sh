#!/bin/bash

read -p "Enter the text: " text
read -p "Enter the word/character to count: " search

count=$(echo "$text" | grep -o "$search" | wc -l)

echo "The word/character '$search' appears $count times in the given text."

