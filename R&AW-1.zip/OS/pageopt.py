def optimal(page_sequence, frame_count):
    frames = []
    page_faults = 0

    for i in range(len(page_sequence)):
        page = page_sequence[i]
        if page not in frames:
            if len(frames) < frame_count:
                frames.append(page)
            else:
                future_indices = [page_sequence[i:].index(frame) if frame in page_sequence[i:] else float('inf') for frame in frames]
                farthest_index = future_indices.index(max(future_indices))
                frames[farthest_index] = page
            page_faults += 1
        print(f"Frames: {frames}")
    print(f"Total Page Faults: {page_faults}")

pages = list(map(int, input("Enter page sequence (space-separated): ").split()))
frame_count = int(input("Enter number of frames: "))
optimal(pages, frame_count)

