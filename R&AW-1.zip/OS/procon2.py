import threading
import time
import random


# Buffer and Lock
buffer = []
buffer_size = int(input("Enter buffer size: "))
mutex = threading.Lock()

# Condition Variables
not_full = threading.Condition(mutex)
not_empty = threading.Condition(mutex)

# Stop flag to indicate when to stop the threads
stop_flag = False

# Producer Function
def producer():
    global stop_flag
    while not stop_flag:
        item = random.randint(1, 100)
        with not_full:
            while len(buffer) == buffer_size:
                not_full.wait()
            buffer.append(item)
            print(f"Produced: {item}, Buffer: {buffer}")
            not_empty.notify()
        time.sleep(random.random())

# Consumer Function
def consumer():
    global stop_flag
    while not stop_flag:
        with not_empty:
            while not buffer:
                not_empty.wait()
            item = buffer.pop(0)
            print(f"Consumed: {item}, Buffer: {buffer}")
            not_full.notify()
        time.sleep(random.random())

# Function to stop threads after a certain time (e.g., 10 seconds)
def stop_threads():
    global stop_flag
    time.sleep(10)  # Run for 10 seconds before stopping
    stop_flag = True  # Signal to stop the threads

# Creating Threads
producer_thread = threading.Thread(target=producer)
consumer_thread = threading.Thread(target=consumer)
stop_thread = threading.Thread(target=stop_threads)

# Start threads
producer_thread.start()
consumer_thread.start()
stop_thread.start()

# Wait for all threads to finish
producer_thread.join()
consumer_thread.join()
stop_thread.join()
