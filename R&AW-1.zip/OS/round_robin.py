# Round Robin Scheduling in Python

def calculate_turnaround_time(arrival_time, finish_time):
    return finish_time - arrival_time

def calculate_waiting_time(turnaround_time, burst_time):
    return turnaround_time - burst_time

def round_robin():
    num_processes = int(input("Enter number of processes: "))
    arrival_times = []
    burst_times = []
    processes = list(range(1, num_processes + 1))

    for i in range(num_processes):
        arrival_time = int(input(f"Enter arrival time for process {i + 1}: "))
        burst_time = int(input(f"Enter burst time for process {i + 1}: "))
        arrival_times.append(arrival_time)
        burst_times.append(burst_time)

    time_quantum = int(input("Enter time quantum: "))
    
    remaining_burst_times = burst_times.copy()  # to track remaining burst time for each process
    current_time = 0
    finished_processes = 0
    finish_times = [-1] * num_processes
    gantt_chart = []
    waiting_times = [0] * num_processes
    turnaround_times = [0] * num_processes

    while finished_processes < num_processes:
        for i in range(num_processes):
            if arrival_times[i] <= current_time and remaining_burst_times[i] > 0:
                gantt_chart.append(f"P{i+1}")
                if remaining_burst_times[i] > time_quantum:
                    current_time += time_quantum
                    remaining_burst_times[i] -= time_quantum
                else:
                    current_time += remaining_burst_times[i]
                    remaining_burst_times[i] = 0
                    finish_times[i] = current_time
                    finished_processes += 1
                    turnaround_times[i] = calculate_turnaround_time(arrival_times[i], finish_times[i])
                    waiting_times[i] = calculate_waiting_time(turnaround_times[i], burst_times[i])

    # Display results
    print("\nProcess\tArrival Time\tBurst Time\tFinish Time\tTurnaround Time\tWaiting Time")
    for i in range(num_processes):
        print(f"P{i + 1}\t{arrival_times[i]}\t\t{burst_times[i]}\t\t{finish_times[i]}\t\t{turnaround_times[i]}\t\t{waiting_times[i]}")

    print("\nGantt Chart: ", " -> ".join(gantt_chart))

if __name__ == "__main__":
    round_robin()

